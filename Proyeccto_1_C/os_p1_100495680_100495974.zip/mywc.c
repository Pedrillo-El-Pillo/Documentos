//P1-SSOO-23/24

#include <stdio.h>

//Constants
#define NO_ERROR 0
#define ERROR_INVALID_ARGUMENTS -1
#define ERROR_FILE_NOT_FOUND -2
#define ERROR_FILE_READ_FAILED -3
#define ERROR_FILE_CLOSE_FAILED -4
#define MAX_FILE_LEN 4096

int iTreatFileError( int iError) {
  switch (iError)
  {
    case ERROR_INVALID_ARGUMENTS:
      printf( "Error %s is and invalid argument\n");
      iError = -1;
    break;

    case ERROR_FILE_READ_FAILED:
      printf( "Error reading file\n" );
    break;

    case ERROR_FILE_CLOSE_FAILED:
      printf( "Error closing file\n" );
    break;

    case ERROR_FILE_NOT_FOUND:
      printf( "Error opening file\n" );
      iError = -1;
break;

    default:
      printf( "Error: Unknown error code %d\n", iError );
    break;
  } //endswitch
  
  return (iError);
  
} 

int main(int argc, char *argv[])
{
  int iFD, i;
  char cBuffer[MAX_FILE_LEN]; // Buffer to store read data
  int iBytesRead;
  int iCharCount = 0;
	/*If less than two arguments (argv[0] -> program, argv[1] -> file to process) print an error y return -1*/
	if(argc < 2)
	{
		return (iTreatFileError( ERROR_INVALID_ARGUMENTS ));
	}
    // Open the file using open() system call
    iFD = open(argv[1], 0); 
    if (iFD == -1) {
        return (iTreatFileError( ERROR_FILE_NOT_FOUND ));
    }

    // Read from the file using read() system call
    

    while ((iBytesRead = read(iFD, cBuffer, sizeof(cBuffer))) > 0) {
        // Count characters in the buffer
        for (int i = 0; i < iBytesRead; i++) {
            if (cBuffer[i] != '\0') {
                iCharCount++;
            }
        }
    }

    if (iBytesRead == -1) {
        close(iFD);
        return (iTreatFileError( ERROR_FILE_READ_FAILED ));
    }

    // Close the file using close() system call
    if (close(iFD) == -1) {
        return (iTreatFileError( ERROR_FILE_CLOSE_FAILED ));
    }

    printf("Total characters in the file: %d\n", iCharCount);

    return 0;
}