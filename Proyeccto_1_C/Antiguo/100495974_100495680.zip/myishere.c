#include <stdio.h>		// Header file for system call printf
#include <unistd.h>		// Header file for system call gtcwd
#include <sys/types.h>	// Header file for system calls opendir, readdir y closedir
#include <dirent.h>
#include <string.h>


int main(int argc, char *argv[])
{
	if(argc != 3) // Check the number of arguments
	{
		printf("Number of arguments is %i not 3\n",argc);
		return -1;
	}
    
    DIR *dir;
    struct dirent *entry;
    int found; 
    if ((dir = opendir(argv[1])) == NULL) { // Give the value to the directory and compare its not null
        printf("Directory not found\n ");
        return -1;
    }
    found = -1; // We give -1 so that if it is not changed we return it as the error return
    while ((entry = readdir(dir)) != NULL) // Iterate the elemnts of the directory.
      {
        if (strcmp(argv[2], entry->d_name) == 0){  // Look if they are the same to the one to be searched
        printf("File %s found\n",entry->d_name);
        found = 0;} // We change the returned variable
    }
    
    if (found != 0){ // Print if not found
    printf("File %s not found\n ",argv[2] );
    } 

    closedir(dir);
    return found;
}